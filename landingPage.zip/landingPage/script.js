let canvas = document.getElementById('canvas');
let currentText;
function changeBar(nextBar){
	let textBar = document.getElementById("textBar");
	let shapeBar = document.getElementById("shapeBar");
	let backgroundBar = document.getElementById("backgroundBar");
	let mainBar = document.getElementById("mainBar");

	if(nextBar == "main"){
		textBar.setAttribute("style", "display:none");
		backgroundBar.setAttribute("style", "display:none");
		shapeBar.setAttribute("style", "display:none");
		mainBar.setAttribute("style", "display:block");
	}
	else if(nextBar == 'Text'){
		textBar.setAttribute("style", "display:block");
		mainBar.setAttribute("style", "display:none");
	}
	else if(nextBar == 'Background'){
		backgroundBar.setAttribute("style", "display:block");
		mainBar.setAttribute("style", "display:none");
	}
	else if(nextBar == 'Shapes'){
		shapeBar.setAttribute("style", "display:block");
		mainBar.setAttribute("style", "display:none");
	}
}



function setBackground(obj){
		console.log(obj.value);
		let hold = obj.value;
		canvas.setAttribute("style", "background-color:" + hold);
}

let gradientColors = ['white', 'white'];
function setGradientBackground(index, obj){
	gradientColors[index] = obj.value;
	console.log(gradientColors[index]);
	canvas.style.backgroundImage = "linear-gradient(" + gradientColors[0] + "," + gradientColors[1] + ")";
}
function setFile(obj){
	console.log(obj.value);
	canvas.style.backgroundImage = "url(" + obj.value + ")";
}
function setBackgroundSize(type){
	console.log(type);
	canvas.setAttribute("style", "background-size:" + type)
	setFile(document.getElementById("urlInput"));

}

function createTextBox(){
	let hold = document.createElement('p');
	hold.innerHTML = "New Text";
	hold.setAttribute("style", "position:absolute; top: 45%; left: 50%; white-space: pre-wrap;");
	hold.setAttribute("onclick", "setCurrent(this)");
	canvas.appendChild(hold);
	currentText=hold;
}


function setCurrent(obj){
	currentText=obj;
	document.getElementById("textInput").value = currentText.innerHTML;
}
function setText(input){
	currentText.innerHTML = input.value;
}
function setTextColor(input){
	currentText.style.color = input.value;
}
function changeTextFont(input){
	currentText.style.fontFamily = input.value;
}
function changeFontSize(input){
	currentText.style.fontSize = input.value + "px";
}
function setPositionText(index, input){
	if(input.value < 0){
		input.value = 0;
	}
	if(index == 'x'){
		currentText.style.left = input.value + "px";
	}
	if(index == 'y'){
		currentText.style.top = input.value + "px";
	}
}
function setTextAlign(loc){
	currentText.style.textAlign = loc;
}



//go back button to landing page
function goBack() {
	window.history.back();
  }